﻿#region 程序集 SM.Media.Platform.WP8.dll, v1.2.2.0
// C:\Users\xyl\Documents\《Windows+Phone8开发技巧与案例精解》随书源码\phonesm-1.2.2\phonesm-1.2.2\bin\Debug\WP8\ARM\SM.Media.Platform.WP8.dll
#endregion

using System;

namespace SM.Media.Utility
{
    public static class ApplicationInformationFactory
    {
        public static IApplicationInformation Default { get; set; }
    }
}
